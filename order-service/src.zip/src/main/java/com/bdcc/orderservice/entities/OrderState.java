package com.bdcc.orderservice.entities;

public enum OrderState {
    PENDING,
    CONFIRMED,
    CANCELED,
    EXECUTED
}
