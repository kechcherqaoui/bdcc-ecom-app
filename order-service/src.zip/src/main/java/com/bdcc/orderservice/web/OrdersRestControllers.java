package com.bdcc.orderservice.web;


import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class OrdersRestControllers {
//    private final OrderRepository orderRepository;
//    private final InventoryRestClient inventoryRestClient;


//    @GetMapping("/orders")
//    public List<Order> findAllOrders(){
//        List<Order> allOrders = orderRepository.findAll();
//        allOrders.forEach(o->{
//            o.getProductItems().forEach(pi->{
//                pi.setProduct(inventoryRestClient.findProductById(pi.getProductId()));
//            });
//        });
//        return allOrders;
//    }
//    @GetMapping("/orders/{id}")
//    public Order findOrderById(@PathVariable String id){
//        Order order = orderRepository.findById(id).get();
//        order.getProductItems().forEach(pi->{
//            pi.setProduct(inventoryRestClient.findProductById(pi.getProductId()));
//        });
//        return order;
//    }
}
